# It's Coming Home — House World Cup 2026 Sweepstake 🏴󠁧󠁢󠁥󠁮󠁧󠁿

A self-contained web page for our house sweepstake. Open `index.html` in any browser, or visit the live site once GitHub Pages is on.

## The rules

- 8 players, 2 teams each.
- **Winner takes all** — whoever drew the team that *wins the World Cup* takes the whole pot. Nothing else pays.
- A player is knocked out once **both** their teams are eliminated.

## Who drew what

| Player  | Teams                  |
|---------|------------------------|
| Josh    | Spain, Belgium         |
| Aaron   | Portugal, Uruguay      |
| Sam     | England, Senegal       |
| Jenn    | France, Ivory Coast    |
| Joe     | Argentina, Norway      |
| Jamie   | Netherlands, Morocco   |
| Justin  | Brazil, Colombia       |
| Aisling | Germany, Japan         |

## Pages

- **Standings** — who's still in it vs knocked out
- **Groups** — live group tables
- **Fixtures** — results and upcoming games (house teams highlighted)
- **Knockout** — the bracket, fills in after the groups finish
- **Group Points** — a bit of fun; doesn't decide the pot

## Updating scores

Open `index.html`, find the `TEAMS` block near the top of the `<script>`. Set a team's `alive: false` when it's eliminated, or update its `round` as it progresses, and adjust the points in `GROUP_ROSTERS`. Commit the change and the live site refreshes within a minute.

*Stella branding is just for our private house page — not for anything public or commercial.*
